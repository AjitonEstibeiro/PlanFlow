@echo off
"%~dp0.venv\Scripts\python.exe" "%~dp0Recover_MySQL.py"
